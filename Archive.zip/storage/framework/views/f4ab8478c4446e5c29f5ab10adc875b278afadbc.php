<?php echo $__env->make('headeradmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('isi'); ?>



  <table id="table_id" class="display">
          <thead>
            <tr>
                <th>No</th>
                <th>Foto</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Tanggal Lahir</th>
                <th>No.Telepon</th>
                <th>Penyakit</th>
                <th>Action</th>
                <th>Konfirmasi</th>
                <th>Status</th>
            </tr>
          </thead>

          <tbody>
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e(++$index); ?></td>
              <td><img src="<?php echo e(asset('storage/'.$value->foto)); ?>" style="width: 100px"></td>
              <td><?php echo e($value->nama_lengkap); ?></td>
              <td><?php echo e($value->email); ?></td>
              <td><?php echo e($value->tanggal_lahir); ?></td>
              <td><?php echo e($value->phone); ?></td>
              <td><?php echo e($value->penyakit); ?></td>

              <td>
                <table>
                    <a href="<?php echo e(route('detailuser',['detailuser'=>$value->id])); ?>"><button class="btn btn-success btn-small green accent-4">Show</button></a>
                                 &nbsp;
                    <a href="<?php echo e(route('useredit',['useredit'=>$value->id])); ?>"><button class="btn btn-warning btn-small">Edit</button></a>
                                &nbsp;

                                <form action="/delete/<?php echo e($value->id); ?>" method="post">
                                                      <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="_method" value="delete">
                                        <button class="btn btn-danger btn-small red accent-4">Delete</button>
                                </form>
                </table>

              </td>
              <td>
                <table>
                  <form action="<?php echo e(route('konfirmasi',['konfirmasi'=>$value->id])); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="_method" value="PUT">
                      <button class="btn btn-success btn-small green accent-4" >Setujui</button>
                  </form>


                </table>

              </td>
              <td><?php echo e($value->status); ?></td>
            </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>

        


<script type="text/javascript">
$(document).ready( function () {
    $('#table_id').DataTable();
} );


swal({
  title: "Are you sure?",
  text: "Once deleted, you will not be able to recover this imaginary file!",
  icon: "warning",
  buttons: true,
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {
    swal("Poof! Your imaginary file has been deleted!", {
      icon: "success",
    });
  } else {
    swal("Your imaginary file is safe!");
  }
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tamplatetampilan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>