
<?php $__env->startSection('header'); ?>


  <ul id="dropdown1" class="dropdown-content">
    <li><a href="<?php echo e(route('profpelatih')); ?>">Pelatih</a></li>
    <li><a href="<?php echo e(route('profpemain')); ?>">Pemain</a></li>
  </ul>


  <nav class="blue-grey darken-4">
    <div class="nav-wrapper">

      <ul class="right hide-on-med-and-down">
        <li><a href="<?php echo e(route('home')); ?>" ><i class="material-icons left">home</i>Home</a></li>
        <li><a href="<?php echo e(route('gallery')); ?>"><i class="material-icons left">collections</i>Gallery</a></li>
        <li><a href="<?php echo e(route('daftar')); ?>"><i class="material-icons left">content_paste</i>Pendaftaran</a></li>
        <li><a class="dropdown-trigger" data-target="dropdown1">Profile<i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a href="<?php echo e(route('about')); ?>" ><i class="material-icons left">info</i>About</a></li>
        <li><a href="<?php echo e(route('homeadmin')); ?>" >Login</a>
      </ul>
    </div>
  </nav>


  <script type="text/javascript">
  document.addEventListener('DOMContentLoaded', function() {
  var elems = document.querySelectorAll('.dropdown-trigger');
  var instances = M.Dropdown.init(elems, instances);
});
  </script>

<?php $__env->stopSection(); ?>
