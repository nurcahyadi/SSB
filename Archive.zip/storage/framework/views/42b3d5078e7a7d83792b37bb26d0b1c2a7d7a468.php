<?php echo $__env->make('headeradmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('isi'); ?>
  <!-- Page Layout here -->
    <div class="row">

      <div class="col s3">
        <!-- Grey navigation panel -->
        <br>

        <img src="<?php echo e(asset('storage/' .$aboutshow->foto_prestasi)); ?>" style="width: 350px" >

        <a class="waves-effect waves-light btn-small" href="<?php echo e(route('homeaboutadmin')); ?>"><i class="material-icons left">home</i>Back to home</a>
      </div>

      <div class="col s9">
        <table class="table">
                                        <tr>
                                          <th>Nama Prestasi</th>
                                          <td><?php echo e($aboutshow->nama_prestasi); ?></td>
                                        </tr>
                                        <tr>
                                          <th>Tanggal Event</th>
                                          <td><?php echo e($aboutshow->tanggal); ?></td>
                                        </tr>
                                        <tr>
                                          <th>Deskripsi</th>
                                          <td><?php echo e($aboutshow->deskripsi); ?></td>
                                        </tr>


                                      </table>

      </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tamplatetampilan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>