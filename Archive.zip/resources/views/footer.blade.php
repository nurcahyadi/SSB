@section('footer')

<style media="screen">
  .txt{
    text-align: center;
  }
</style>
  <footer class="page-footer blue-grey darken-4">
         <div class="footer-copyright">
           <div class="container txt" >
           Hak Cipta © 2014 Sekolah Sepakbola Mutiara97 Kota Bogor

           </div>
         </div>
       </footer>

@endsection
