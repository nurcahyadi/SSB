<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('isi'); ?>
  <?php echo $__env->make('slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row">
  <div class="col s4 right">
    <nav class="grey">
       <div class="nav-wrapper">
         <form>
           <div class="input-field">
             <input id="search" type="search" required placeholder="Search">
             <label class="label-icon" for="search"><i class="material-icons">search</i></label>
             <i class="material-icons">close</i>
           </div>
         </form>
       </div>
     </nav>
  </div>
</div>

<div class="row">
  <?php $__currentLoopData = $pemain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col s6">

    <div class="card horizontal">
      <div class="card-image" >
        <img src="<?php echo e(asset('storage/'.$value->foto)); ?>" height="250" >
      </div>
      <div class="card-stacked">
        <div class="card-content">
          <p>Nama : <?php echo e($value->nama_lengkap); ?></p>
          <p>Tempat Lahir : <?php echo e($value->tempat_lahir); ?></p>
          <p>Tanggal Lahir : <?php echo e($value->tanggal_lahir); ?></p>
        </div>
        <div class="card-action">
          <a href="#">Read More</a>
        </div>
      </div>
    </div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('tamplatetampilan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>