<?php echo $__env->make('headeradmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('isi'); ?>
  <!-- Page Layout here -->
    <div class="row">

      <div class="col s3">
        <!-- Grey navigation panel -->
        <br>

        <img src="<?php echo e(asset('storage/' .$pelatih->foto)); ?>" style="width: 350px" >

        <a class="waves-effect waves-light btn-small" href="<?php echo e(route('homepelatihadmin')); ?>"><i class="material-icons left">home</i>Back to home</a>
      </div>

      <div class="col s9">
        <table class="table">
                                        <tr>
                                          <th>Nama Lengkap</th>
                                          <td><?php echo e($pelatih->nama_lengkap); ?></td>
                                        </tr>
                                        <tr>
                                          <th>Tempat Lahir</th>
                                          <td><?php echo e($pelatih->tempat_lahir); ?></td>
                                        </tr>
                                        <tr>
                                          <th>Tanggal Lahir</th>
                                          <td><?php echo e($pelatih->tanggal_lahir); ?></td>
                                        </tr>
                                        <tr>
                                          <th>No.Telepon</th>
                                          <td><?php echo e($pelatih->phone); ?></td>
                                        </tr>
                                        <tr>
                                          <th>Email</th>
                                          <td><?php echo e($pelatih->email); ?></td>
                                        </tr>
                                        <tr>
                                          <th>Alamat Rumah</th>
                                          <td><?php echo e($pelatih->alamat_rumah); ?></td>
                                        </tr>


                                      </table>

      </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tamplatetampilan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>