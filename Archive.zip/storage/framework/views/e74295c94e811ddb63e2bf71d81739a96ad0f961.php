<?php echo $__env->make('headeradmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('isi'); ?>
  <!-- Page Layout here -->
    <div class="row">

      <div class="col s3">
        <!-- Grey navigation panel -->
        <br>

        <img src="<?php echo e(asset('storage/'.$user->foto)); ?>" style="width: 350px" >

        <a class="waves-effect waves-light btn-small" href="<?php echo e(route('homeadmin')); ?>"><i class="material-icons left">home</i>Back to home</a>
      </div>

      <div class="col s9">
        <table class="table">
                                        <tr>
                                          <th>Nama</th>
                                          <td><?php echo e($user->nama_lengkap); ?></td>
                                        </tr>
                                        <tr>
                                          <th>NISN</th>
                                          <td><?php echo e($user->NISN); ?></td>
                                        </tr>
                                        <tr>
                                          <th>Email</th>
                                          <td><?php echo e($user->email); ?> set</td>
                                        </tr>
                                        <tr>
                                          <th>Nama Orang Tua</th>
                                          <td><?php echo e($user->nama_ortu); ?></td>
                                        </tr>
                                        <tr>
                                          <th>Pekerjaan Orang Tua</th>
                                          <td><?php echo e($user->pekerjaan_ortu); ?></td>
                                        </tr>
                                        <tr>
                                          <th>Tempat Lahir</th>
                                          <td><?php echo e($user->tempat_lahir); ?></td>
                                        </tr>
                                        <tr>
                                          <th>Tanggal Lahir</th>
                                          <td><?php echo e($user->tanggal_lahir); ?></td>
                                        </tr>
                                        <tr>
                                          <th>No.Telepon</th>
                                          <td><?php echo e($user->phone); ?></td>
                                        </tr>
                                        <tr>
                                          <th>Alamat Rumah</th>
                                          <td><?php echo e($user->alamat_rumah); ?></td>
                                        </tr>
                                        <tr>
                                          <th>Asal Sekolah</th>
                                          <td><?php echo e($user->sekolah_asal); ?></td>
                                        </tr>
                                        <tr>
                                          <th>Alamat Sekolah</th>
                                          <td><?php echo e($user->alamat_sekolah); ?></td>
                                        </tr>
                                        <tr>
                                          <th>Asal SSB</th>
                                          <td><?php echo e($user->asal_ssb); ?></td>
                                        </tr>
                                        <tr>
                                          <th>Golongan Darah</th>
                                          <td><?php echo e($user->gol_darah); ?></td>
                                        </tr>
                                        <tr>
                                          <th>Tinggi Badan</th>
                                          <td><?php echo e($user->tinggi); ?></td>
                                        </tr>
                                        <tr>
                                          <th>Berat Badan</th>
                                          <td><?php echo e($user->berat); ?></td>
                                        </tr>
                                        <tr>
                                          <th>Penyakit</th>
                                          <td><?php echo e($user->penyakit); ?></td>
                                        </tr>
                                        <tr>
                                          <th>Kartu Keluarga</th>
                                          <td><img src="<?php echo e(asset('storage/'.$user->kartu_keluarga)); ?>" style="width: 50px" ></td>
                                        </tr>
                                        <tr>
                                          <th>Akte Kelahiran</th>
                                          <td><img src="<?php echo e(asset('storage/'.$user->akte_kelahiran)); ?>" style="width: 50px" ></td>
                                        </tr>
                                        <tr>
                                          <th>Rapot</th>
                                          <td><img src="<?php echo e(asset('storage/'.$user->rapot)); ?>" style="width: 50px" ></td>
                                        </tr>


                                      </table>

      </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tamplatetampilan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>