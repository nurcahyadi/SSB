<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('isi'); ?>
  <?php echo $__env->make('slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row">
  <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


  <div class="col s3">
    <div class="card">
      <div class="card-image waves-effect waves-block waves-light">
        <img class="activator" src="<?php echo e(asset('storage/'.$value->foto_gallery)); ?>">
      </div>
      <div class="card-content">
        <span class="card-title activator grey-text text-darken-4"><?php echo e($value->nama_gallery); ?><i class="material-icons right">more_vert</i></span>
        <p><a href="#">Read More</a></p>
      </div>
      <div class="card-reveal">
        <span class="card-title grey-text text-darken-4"><?php echo e($value->nama_gallery); ?><i class="material-icons right">close</i></span>
        <p><?php echo e($value->deskripsi); ?></p>
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('tamplatetampilan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>