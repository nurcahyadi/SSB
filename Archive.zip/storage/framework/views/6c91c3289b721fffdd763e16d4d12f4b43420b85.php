<?php echo $__env->make('headeradmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('isi'); ?>

<div class="row">
  <form class="card col s6 offset-s3" action="<?php echo e(route('statuspembayaran')); ?>" method="post">
      <?php echo e(csrf_field()); ?>




        <div class="row">
          <div class="input-field col s6" >
        <select name="nama" >
          <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($value->id); ?>"><?php echo e($value->nama_lengkap); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label>Nama</label>
        </div>
      </div>

      <div class="row">
        <div class="input-field col s8">
          <input name="tanggal_pembayaran" type="text" class="datepicker">
          <label>Tanggal Pembayaran</label>
        </div>
      </div>

      <div class="row">
        <div class="input-field col s8">
          <input name="total_pembayaran" type="number" class="validate">
          <label>Total Pembayaran</label>
        </div>
      </div>

      <div class="row">
        <div class="input-field col s6" >
      <select name="status_pembayaran" >
      <option value="" disabled selected>Choose your option</option>
      <option value="Belum Bayar">Belum Bayar</option>
      <option value="Sudah Bayar">Sudah Bayar</option>
    </select>
    <label>Status Pembayaran</label>
  </div>

  <div class="input-field col s6" >
<select name="keterangan" >
<option value="" disabled selected>Choose your option</option>
<option value="Pendaftaran">Pendaftaran</option>
<option value="Bulanan">Bulanan</option>
<option value="Kaos">Kaos</option>
<option value="lainlain">Lain-lain</option>
</select>
<label>Keterangan</label>
</div>
</div>

<div class="row">
  <div class="input-field col s12">
    <input name="ket_lainlain" type="text" class="validate">
    <label>Keterangan Lain-lain</label>
  </div>
</div>
  <div class="row">
    <div class="col s2 offset-s5">
      <button class="btn waves-effect waves-light" type="submit" name="action">Save
          <i class="material-icons right">send</i>
        </button>
    </div>
  </div>
  </form>






  <script type="text/javascript">
document.addEventListener('DOMContentLoaded', function() {
  var elems = document.querySelectorAll('.datepicker');
  var instances = M.Datepicker.init(elems, instances);
});

document.addEventListener('DOMContentLoaded', function() {
  var elems = document.querySelectorAll('select');
  var instances = M.FormSelect.init(elems, instances);
});

  </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('tamplatetampilan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>