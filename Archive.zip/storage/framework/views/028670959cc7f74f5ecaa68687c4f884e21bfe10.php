<?php echo $__env->make('headeradmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('isi'); ?>

  <div class="row">

  </div>

<br>
<div class="row">
  <div class="col s2 offset-s5">
    <a href="/pembayaran" class="waves-effect waves-light btn-large">Tambah</a>
  </div>
</div>


  <table id="table_id" class="display">
          <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Tanggal Lahir</th>
                <th>Tanggal Pembayaran</th>
                <th>Total Pembayaran</th>
                <th>Keterangan</th>
                <th>Status Pembayaran</th>
                <th>Keterangan Lain-lain</th>
                <th>Action</th>
            </tr>
          </thead>

          <tbody>
            <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e(++$index); ?></td>
              <td><?php echo e($value->user->nama_lengkap); ?></td>
              <td><?php echo e($value->user->tanggal_lahir); ?></td>
              <td><?php echo e($value->tanggal_pembayaran); ?></td>
              <td><?php echo e($value->total_pembayaran); ?></td>
              <td><?php echo e($value->keterangan); ?></td>
              <td><?php echo e($value->status_pembayaran); ?></td>
              <td><?php echo e($value->ket_lainlain); ?></td>

              <td>
                <table>

                    <a href="<?php echo e(route('transaksiedit',['transaksiedit'=>$value->id])); ?>"><button class="btn btn-warning">Edit</button></a>

                </table>

              </td>
            </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>


        <script type="text/javascript">
        $(document).ready( function () {
            $('#table_id').DataTable();
        } );

        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tamplatetampilan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>