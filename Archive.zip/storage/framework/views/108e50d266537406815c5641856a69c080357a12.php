<?php echo $__env->make('headeradmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('isi'); ?>

<div class="pad">
<a href="/toabout"> <button type="button" class="btn btn-primary" style="float: right; margin-right:20px; margin-top:20px;">Tambah</button></a>

  <table id="table_id" class="display">
          <thead>
            <tr>
                <th>No</th>
                <th>Foto</th>
                <th>Waktu</th>
                <th>Nama Prestasi</th>
                <th>Deskripsi</th>
                <th>Action</th>

            </tr>
          </thead>

          <tbody>
            <?php $__currentLoopData = $prestasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e(++$index); ?></td>
              <td><img src="<?php echo e(asset('storage/'.$value->foto_prestasi)); ?>" style="width: 100px"></td>
              <td><?php echo e($value->tanggal); ?></td>
              <td><?php echo e($value->nama_prestasi); ?></td>
              <td><?php echo e($value->deskripsi); ?></td>

              <td>
                <table>
                    <a href="<?php echo e(route('detailabout',['aboutshow'=>$value->id])); ?>"><button class="btn btn-success btn-small green accent-4">Show</button></a>
                                 &nbsp;
                    <a href="<?php echo e(route('editabout',['editabout'=>$value->id])); ?>"><button class="btn btn-warning btn-small">Edit</button></a>
                                &nbsp;

                                <form action="/deleteabout/<?php echo e($value->id); ?>" method="post">
                                                      <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="_method" value="delete">
                                        <button class="btn btn-danger btn-small red accent-4 margin">Delete</button>
                                </form>
                </table>

              </td>
            </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>

</div>

<script type="text/javascript">
$(document).ready( function () {
    $('#table_id').DataTable();
} );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tamplatetampilan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>