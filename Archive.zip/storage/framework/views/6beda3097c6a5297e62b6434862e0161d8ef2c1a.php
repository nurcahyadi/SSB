<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('isi'); ?>
<br>

<div class="row">
    <form class="card col s6 offset-s3" action="/createpelatih" method="post" enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

      <div class="row">
        <div class="input-field col s12">
          <input name="nama_lengkap" type="text" class="validate" required>
          <label >Nama Lengkap*</label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s12">
          <input name="tempat_lahir" type="text" class="validate" required>
          <label>Tempat Lahir*</label>
        </div>
      </div>

      <div class="row">
        <div class="input-field col s12">
          <input name="tanggal_lahir" type="text" class="datepicker" required>
          <label>Tanggal Lahir*</label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s12">
           <i class="material-icons prefix">phone</i>
           <input name="phone" type="number" class="validate" required>
           <label>Telephone/No.Hp*</label>
         </div>
      </div>

      <div class="row">
        <div class="input-field col s12">
           <i class="material-icons prefix">email</i>
           <input name="email" type="email" class="validate">
           <label>Email</label>
         </div>
      </div>

      <div class="row">
        <div class="file-field input-field col s12">
          <div class="btn">
            <span>File</span>
            <input name="foto" type="file" value="<?php echo e(asset('storage/foto/avatar.png')); ?>" >
          </div>
          <div class="file-path-wrapper">
           <input class="file-path validate"  type="text" placeholder="Masukan Foto Pelatih*" required>
        </div>
       </div>
      </div>

      <div class="row">
        <div class="input-field col s12">
          <textarea name="alamat_rumah" class="materialize-textarea" required></textarea>
          <label >Alamat Rumah*</label>
        </div>
      </div>
<h5>Note: bagi field yang diberi tanda (*) wajib diisi</h5>
<br>
<div class="row">
  <div class="col s2 offset-s5">
    <button class="btn waves-effect waves-light" type="submit" name="action">Submit
        <i class="material-icons right">send</i>
      </button>
  </div>
</div>

    </form>
  </div>




    <script type="text/javascript">
// document.addEventListener('DOMContentLoaded', function() {
//     var elems = document.querySelectorAll('.datepicker');
//     var instances = M.Datepicker.init(elems, instances);
//   });
$(document).ready(function(){
    $('.datepicker').datepicker();
  });

  document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('select');
    var instances = M.FormSelect.init(elems, instances);
  });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('tamplatetampilan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>